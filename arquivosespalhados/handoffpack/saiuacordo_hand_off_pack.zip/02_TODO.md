# TODO — Frontend & Integração (Sprints)

## Sprint 1 — Trust & Compare
- [ ] Substituir trust bar pela versão premium (HTML/CSS deste pacote).
- [ ] Trocar “compare” pelo híbrido (mapa negativo ↔ solução simples).
- [ ] Atualizar logos reais (SVG), tema dark e animações leves (CSS-only).

## Sprint 2 — Logos & “Empresas que confiam”
- [ ] Grid com logos reais, duo-tone no dark, hover brighten.
- [ ] Mobile com scroll-snap; desktop em mosaico responsivo.

## Sprint 3 — A11y & UX polish
- [ ] Revisar aria-atributos (tabs/accordion).
- [ ] Estados de foco e `prefers-reduced-motion`.

## Sprint 4 — Performance
- [ ] Minificar CSS/JS (pipeline Django).
- [ ] Auditar Lighthouse e corrigir (≥95).

## Preparação para Backend
- [ ] Padronizar contratos de resposta (erros/OK) em `signup_post`/`login_post`.
- [ ] Mapear endpoints de: comunicação (SMS/e-mail/WhatsApp), pagamentos (Pix/Boleto/Cartão), dados (SERASA/Big Data), judicial.
- [ ] Criar placeholders visuais (badges/estados) para binding futuro.
